from .email import Email


class Bcc(Email):
    """A bcc email address with an optional name."""
