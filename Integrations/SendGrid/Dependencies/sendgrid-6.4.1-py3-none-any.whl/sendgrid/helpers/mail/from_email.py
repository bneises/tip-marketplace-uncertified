from .email import Email


class From(Email):
    """A from email address with an optional name."""
