from .ioc_fanger import defang, fang

__author__ = 'Floyd Hightower'
__version__ = '3.4.0'
