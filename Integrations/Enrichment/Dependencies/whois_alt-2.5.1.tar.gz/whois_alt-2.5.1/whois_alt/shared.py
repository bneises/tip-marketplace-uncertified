class WhoisException(Exception):
	pass
